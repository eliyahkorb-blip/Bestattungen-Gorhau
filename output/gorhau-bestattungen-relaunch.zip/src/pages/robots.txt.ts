import type { APIRoute } from 'astro';
import { isPreviewBuild, absoluteUrl } from '../utils/url';

export const GET: APIRoute = () => {
  const body = isPreviewBuild()
    ? `User-agent: *
Disallow: /
`
    : `User-agent: *
Allow: /

Sitemap: ${absoluteUrl('/sitemap.xml')}
`;

  return new Response(body, {
    headers: { 'Content-Type': 'text/plain; charset=utf-8' },
  });
};
